module.exports = (client, int) => {
    if (!int.isButton()) return;

    const queue = player.getQueue(int.guildId);

    switch (int.customId) {
        case 'saveTrack': {
            if (!queue || !queue.playing) return int.reply({ content: `Nenhuma música tocando no momento... tente novamente? ❌`, ephemeral: true, components: [] });

            int.member.send(`Você salvou a faixa ${queue.current.title} | ${queue.current.author} do servidor ${int.member.guild.name} ✅`).then(() => {
                return int.reply({ content: `Te mandei o titulo da musica por mensagem privada ✅`, ephemeral: true, components: [] });
            }).catch(error => {
                return int.reply({ content: `Não foi possível enviar uma mensagem privada... tente novamente? ❌`, ephemeral: true, components: [] });
            });
        }
    }
};