module.exports = {
    name: 'resume',
    aliases: ['rs'],
    utilisation: '{prefix}resume',
    voiceChannel: true,

    execute(client, message) {
        const queue = player.getQueue(message.guild.id);

        if (!queue) return message.channel.send(`Nenhuma música tocando no momento ${message.author}... tente novamente ? ❌`);

        const success = queue.setPaused(false);

        return message.channel.send(success ? `Música atual ${queue.current.title} retomada ✅` : `Algo deu errado ${message.author}... tente novamente ? ❌`);
    },
};