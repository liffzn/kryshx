module.exports = {
    app: {
        px: '.',
        token: 'OTYxMDQyODY5ODQ0NjA2OTc4.YkzO6w.EjBZ695FYL8Tp8NInrZppJkJ4Z8',
        playing: 'Created by: kryshx'
    },

    opt: {
        DJ: {
            enabled: false,
            roleName: 'DJ',
            commands: ['back', 'clear', 'filter', 'loop', 'pause', 'resume', 'seek', 'shuffle', 'skip', 'stop', 'volume']
        },
        maxVol: 100,
        loopMessage: false,
        discordPlayer: {
            ytdlOptions: {
                quality: 'highestaudio',
                highWaterMark: 1 << 25
            }
        }
    }
};
