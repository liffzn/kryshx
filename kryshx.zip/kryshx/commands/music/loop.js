const { QueueRepeatMode } = require('discord-player');

module.exports = {
    name: 'loop',
    aliases: ['lp', 'repeat'],
    utilisation: '{prefix}loop <queue>',
    voiceChannel: true,

    execute(client, message, args) {
        const queue = player.getQueue(message.guild.id);

        if (!queue || !queue.playing) return message.channel.send(`Nenhuma música tocando no momento ${message.author}... tente novamente ? ❌`);

        if (args.join('').toLowerCase() === 'queue') {
            if (queue.repeatMode === 1) return message.channel.send(`You must first disable the current music in the loop mode (${client.config.app.px}loop) ${message.author}... tente novamente ? ❌`);

            const success = queue.setRepeatMode(queue.repeatMode === 0 ? QueueRepeatMode.QUEUE : QueueRepeatMode.OFF);

            return message.channel.send(success ? `Modo de repetição **${queue.repeatMode === 0 ? 'disabled' : 'enabled'}** toda a fila será repetida infinitamente 🔁` : `Algo deu errado ${message.author}... tente novamente ? ❌`);
        } else {
            if (queue.repeatMode === 2) return message.channel.send(`Você deve primeiro desabilitar a fila atual no modo de loop (${client.config.app.px}loop queue) ${message.author}... tente novamente ? ❌`);

            const success = queue.setRepeatMode(queue.repeatMode === 0 ? QueueRepeatMode.TRACK : QueueRepeatMode.OFF);

            return message.channel.send(success ? `Modo de repetição **${queue.repeatMode === 0 ? 'disabled' : 'enabled'}** a música atual será repetida infinitamente (você pode fazer um loop na fila com a opção <queue>) 🔂` : `Something went wrong ${message.author}... tente novamente ? ❌`);
        };
    },
};