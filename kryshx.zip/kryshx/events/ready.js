module.exports = async (client) => {
    console.log(`Ligado ao cliente ${client.user.username}\n-> Ligado em ${client.guilds.cache.size} servidores, para um total de ${client.users.cache.size} usuários.`);

    client.user.setActivity(client.config.app.playing);
};