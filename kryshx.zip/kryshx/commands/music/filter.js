module.exports = {
    name: 'filter',
    aliases: [],
    utilisation: '{prefix}filter [filter name]',
    voiceChannel: true,

    async execute(client, message, args) {
        const queue = player.getQueue(message.guild.id);

        if (!queue || !queue.playing) return message.channel.send(`Nenhuma música tocando no momento ${message.author}... tente novamente ? ❌`);

        const actualFilter = queue.getFiltersEnabled()[0];

        if (!args[0]) return message.channel.send(`Especifique um filtro válido para ativar ou desativar ${message.author}... tente novamente ? ❌\n${actualFilter ? `Filtro atualmente ativo ${actualFilter} (${client.config.app.px}filter ${actualFilter} para desativá-lo).\n` : ''}`);

        const filters = [];

        queue.getFiltersEnabled().map(x => filters.push(x));
        queue.getFiltersDisabled().map(x => filters.push(x));

        const filter = filters.find((x) => x.toLowerCase() === args[0].toLowerCase());

        if (!filter) return message.channel.send(`Este filtro não existe ${message.author}... tente novamente ? ❌\n${actualFilter ? `Filtro atualmente ativo ${actualFilter}.\n` : ''}Lista de filtros disponíveis ${filters.map(x => `**${x}**`).join(', ')}.`);

        const filtersUpdated = {};

        filtersUpdated[filter] = queue.getFiltersEnabled().includes(filter) ? false : true;

        await queue.setFilters(filtersUpdated);

        message.channel.send(`The filter ${filter} is now **${queue.getFiltersEnabled().includes(filter) ? 'enabled' : 'disabled'}** ✅\n*Lembrete quanto mais longa for a música, mais tempo levará.*`);
    },
};