const Discord = require("discord.js");
const client = new Discord.Client({intents: [ 
    Discord.Intents.FLAGS.GUILDS,
    Discord.Intents.FLAGS.GUILD_MESSAGES,
    Discord.Intents.FLAGS.GUILD_INVITES,
    Discord.Intents.FLAGS.GUILD_MEMBERS,
  ],});
const DisTube = require('distube');
const distube = new DisTube(client, { serchSongs: true, emitNewSongOnly: true});
const { token } = require('./config.json');

client.on("ready", () => {
    console.log(`${client.user.tag} has logged in.`);
});

client.on("message", async (message) => {
    if (message.author.bot) return;
    if (!message.content.startsWith(prefix)) return;
    const args = message.content.slice(prefix.length).trim().split(/ +/g);
    const command = args.shift();

})
client.on('message', (message) => {
    if (message.content == "play") {
        if (!message.member.voice.channel) return message.channel.send('Você não está em um canal para escutar música.');
        if (!args[0]) return message.channel.sned('You must state something to play.');
        distube.play(message.args.join(" "));
    
    }
    
    if (message.content == "stop") {
        const bot = message.guild.members.cache.get(client.user.id);
        if (!message.member.voice.channel) return message.channel.send('You are not in a voice channel.');
        if (bot.voice.channel !== message.memmber.voice.channel) return message.channel.send('You are not in the same voice channel as the bot.');
        distube.stop(message);
        message.channel.send('You have stopped the music.')
    
    }
})

const status = queue => 

    `Volume: \`${queue.volume}%\` | Filter: \`${queue.filters.join(', ') || 'Off'}\` | Loop: \`${queue.repeatMode ? (queue.repeatMode === 2 ? 'All Queue' : 'This Song') : 'Off'
    }\` | Autoplay: \`${queue.autoplay ? 'On' : 'Off'}\``
client.distube
    .on('playSong', (queue, song) =>
        queue.textChannel.send(
            `${client.emotes.play} | :tools: Playing \`${song.name}\` - \`${song.formattedDuration}\`\nRequested by: ${song.user.tag
            }\n${status(queue)}`
        )
    )
    .on('addSong', (queue, song) =>
        queue.textChannel.send(
            `${client.emotes.success} | Added ${song.name} - \`${song.formattedDuration}\` to the queue by ${song.user.tag}`
        )
    )
    .on('addList', (queue, playlist) =>
        queue.textChannel.send(
            `${client.emotes.success} | Added \`${playlist.name}\` playlist (${playlist.songs.length
            } songs) to queue\n${status(queue)}`
        )
    )
    .on('error', (channel, e) => {
        channel.send(`${client.emotes.error} | An error encountered: ${e.toString().slice(0, 1974)}`)
        console.error(e)
    })
    .on('empty', channel => channel.send('Voice channel is empty! Leaving the channel...'))
    .on('searchNoResult', (message, query) =>
        message.channel.send(`${client.emotes.error} | No result found for \`${query}\`!`))

    .on('finish', queue => queue.textChannel.send('Finished!'))


    .on("searchResult", (message, result) => {
        let i = 0
        message.channel.send(
            `**Choose an option from below**\n${result
             .map(song => `**${++i}**. ${song.name} - \`${song.formattedDuration}\``)
             .join("\n")}\n*Enter anything else or wait 60 seconds to cancel*`
        )
    })

    .on("searchCancel", message => message.channel.send(`${client.emotes.error} | Searching canceled`))

    .on("searchInvalidAnswer", message =>
        message.channel.send(
            `${client.emotes.error} | Invalid answer! You have to enter the number in the range of the results`
        )
    )



client.login(token, console.log('estou ligado'));