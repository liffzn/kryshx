player.on('error', (queue, error) => {
    console.log(`Erro emitido da fila ${error.message}`);
});

player.on('connectionError', (queue, error) => {
    console.log(`Erro emitido da conexão ${error.message}`);
});

player.on('trackStart', (queue, track) => {
    if (!client.config.opt.loopMessage && queue.repeatMode !== 0) return;
    queue.metadata.send(`Começou a tocar ${track.title} dentro de **${queue.connection.channel.name}** 🎧`);
});

player.on('trackAdd', (queue, track) => {
    queue.metadata.send(`Seguir ${track.title} adicionado na fila ✅`);
});

player.on('botDisconnect', (queue) => {
    queue.metadata.send('Fui desconectado manualmente do canal de voz, limpando a fila... ❌');
});

player.on('channelEmpty', (queue) => {
    queue.metadata.send('Ninguém está no canal de voz, saindo do canal de voz... ❌');
});

player.on('queueEnd', (queue) => {
    queue.metadata.send('Eu terminei de ler toda a fila✅');
});